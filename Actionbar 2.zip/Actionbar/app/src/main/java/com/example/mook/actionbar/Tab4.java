package com.example.mook.actionbar;

import android.os.Bundle;
import android.app.Activity;
/**
 * Created by yoma on 2/7/15.
 */
public class Tab4 extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.tab4);


    }
}
