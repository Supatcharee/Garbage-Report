package com.example.mook.actionbar;

import android.app.Activity;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.view.View.OnClickListener;

/**
 * Created by mook on 3/18/2015.
 */
public class Tab2 extends Activity implements OnClickListener{

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.tab2);


        Button phone = (Button) findViewById(R.id.phone);
        phone.setOnClickListener(this);

        Button phone1 = (Button) findViewById(R.id.phone1);
        phone1.setOnClickListener(this);


    }
    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.phone:
                Intent DialerIntent = new Intent(Intent.ACTION_DIAL);
                startActivity(DialerIntent);
                break;

            case R.id.phone1 :
                Intent CallIntent = new Intent(Intent.ACTION_CALL);
                String strTelNo = "0874775741";
                Uri data = Uri.parse("tel:"+strTelNo);
                CallIntent.setData(data);
                startActivityForResult(CallIntent, 100);
                break;


        }

    }
}