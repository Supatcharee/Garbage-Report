package com.example.mook.actionbar;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.Menu;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Button;
import android.view.MenuItem;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import android.widget.AdapterView.OnItemSelectedListener;



/**
 * Created by mook on 3/18/2015.
 */
public class Tab1 extends Activity {

    private static final int TAKE_PICTURE = 100;
    private static final int TAKE_PICTURE_SAVE = 101;
    final static int CAMERA_COMPLETE = 100;

    private File imageFile;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.tab1);

        Button takeButton = (Button) findViewById(R.id.takeButton);
        Button buttonsend = (Button) findViewById(R.id.buttonsend);

        final Intent intent = new Intent(this, MapsActivity.class);
        buttonsend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                startActivity(intent);
            }
        });

        takeButton.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                startActivityForResult(intent, CAMERA_COMPLETE);

//                imageFile = new File(Environment.getExternalStorageDirectory(), "my_image.jpg");
//                intent.putExtra(MediaStore.EXTRA_OUTPUT, Uri.fromFile(imageFile));
//                startActivityForResult(intent, TAKE_PICTURE_SAVE);
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
     /* ImageView imageshow = (ImageView) findViewById(R.id.imageshow);

        if (requestCode == TAKE_PICTURE && resultCode == RESULT_OK) {
            Bitmap capturedImage = (Bitmap) data.getExtras().get("data");
            imageshow.setImageBitmap(capturedImage);
        } else if (requestCode == TAKE_PICTURE_SAVE && resultCode == RESULT_OK) {
            try {
                FileInputStream fis = new FileInputStream(imageFile);
                //Bitmap fullSizeImage = BitmapFactory.decodeStream(fis);

                BitmapFactory.Options options = new BitmapFactory.Options();
                options.inSampleSize = 2;
                Bitmap fullSizeImage = BitmapFactory.decodeStream(fis, null, options);

                imageshow.setImageBitmap(fullSizeImage);
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }
        }*/

        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode == RESULT_OK){
            Bundle b = data.getExtras();
            Bitmap bmp =(Bitmap) b.get("data");
            ImageView imag = (ImageView) findViewById(R.id.imageshow);
            imag.setImageBitmap(bmp);
        }
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_actionbar, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}




